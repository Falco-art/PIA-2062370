#!/bin/bash
# Script para recolección de red e investigación de dominios

DOMINIO=$1
LOG_FILE="../logs/sistema.log"
RESULT_FILE="../resultados/recon_data.json"

# Manejo de errores y validación de argumentos
if [ -z "$DOMINIO" ]; then
    echo "$(date '+%Y-%m-%d %H:%M:%S') - ERROR: Faltan argumentos en recon.sh. Uso: ./recon.sh <dominio>" >> "$LOG_FILE"
    exit 1
fi

echo "$(date '+%Y-%m-%d %H:%M:%S') - INFO: Iniciando reconocimiento Bash para $DOMINIO" >> "$LOG_FILE"

# Consulta web a una API pública (Ejemplo de investigación web)
IP_INFO=$(curl -s "http://ip-api.com/json/$DOMINIO")

if [ $? -ne 0 ]; then
    echo "$(date '+%Y-%m-%d %H:%M:%S') - ERROR: Falló la consulta web en recon.sh" >> "$LOG_FILE"
    exit 1
fi

# Guardar en JSON
echo "$IP_INFO" > "$RESULT_FILE"
echo "$(date '+%Y-%m-%d %H:%M:%S') - INFO: Reconocimiento finalizado. Resultados en $RESULT_FILE" >> "$LOG_FILE"