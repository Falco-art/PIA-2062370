import subprocess
import argparse
from modulos.utilidades import logging

def ejecutar_comando(comando, descripcion):
    logging.info(f"Iniciando: {descripcion}")
    try:
        # Ejecución silenciosa capturando la salida[cite: 1]
        resultado = subprocess.run(comando, shell=True, check=True, capture_output=True, text=True)
        logging.info(f"Éxito: {descripcion}")
    except subprocess.CalledProcessError as e:
        logging.error(f"Fallo en {descripcion}. Error: {e.stderr}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Herramienta de Automatización de Seguridad")
    parser.add_argument('-d', '--dominio', required=True, help="Dominio a investigar (ej. google.com)")
    args = parser.parse_args()

    # 1. Ejecutar Bash (Reconocimiento)
    ejecutar_comando(f"cd ../bash && bash recon.sh {args.dominio}", "Reconocimiento de red (Bash)")

    # 2. Ejecutar PowerShell (Auditoría)
    # Ejecuta sin mostrar ventana para cumplir con ejecución silenciosa[cite: 1]
    ejecutar_comando("cd ../powershell && powershell.exe -WindowStyle Hidden -ExecutionPolicy Bypass -File audit.ps1", "Auditoría de sistema (PowerShell)")

    # 3. Analizar y generar reporte (Python)
    ejecutar_comando("cd ../python && python analizador.py", "Análisis y generación de reporte HTML")

    print(f"Proceso completado. Revisa la carpeta 'resultados' y el archivo de logs.")