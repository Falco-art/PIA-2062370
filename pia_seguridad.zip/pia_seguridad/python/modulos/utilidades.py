import hashlib
import json
import logging

# Configuración de logging unificado
logging.basicConfig(
    filename='../logs/sistema.log',
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s: %(message)s'
)

def generar_hash(filepath):
    """Genera un hash MD5 de un archivo (Requisito de cifrado/hashing)."""
    try:
        hasher = hashlib.md5()
        with open(filepath, 'rb') as afile:
            buf = afile.read()
            hasher.update(buf)
        return hasher.hexdigest()
    except Exception as e:
        logging.error(f"Error al generar hash para {filepath}: {e}")
        return None

def cargar_json(filepath):
    """Módulo reutilizable para cargar datos JSON."""
    try:
        with open(filepath, 'r') as file:
            return json.load(file)
    except Exception as e:
        logging.error(f"Error al cargar JSON {filepath}: {e}")
        return {}