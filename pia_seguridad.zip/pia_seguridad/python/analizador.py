import os
from modulos.utilidades import cargar_json, generar_hash, logging

def generar_reporte_html():
    """Genera un reporte HTML combinando datos de Bash y PowerShell."""
    logging.info("Iniciando generación de reporte HTML.")
    
    recon_data = cargar_json('../resultados/recon_data.json')
    audit_data = cargar_json('../resultados/audit_data.json')
    
    # Hash de integridad de los datos crudos[cite: 1]
    recon_hash = generar_hash('../resultados/recon_data.json')
    
    html_content = f"""
    <html>
    <head><title>Reporte de Seguridad</title></head>
    <body style="font-family: Arial; background-color: #f4f4f9; color: #333;">
        <h2>Reporte de Automatización de Ciberseguridad</h2>
        
        <h3>1. Inteligencia de Red (Vía Bash)</h3>
        <p><strong>IP:</strong> {recon_data.get('query', 'N/A')}</p>
        <p><strong>País:</strong> {recon_data.get('country', 'N/A')}</p>
        <p><strong>ISP:</strong> {recon_data.get('isp', 'N/A')}</p>
        <p><em>Hash de integridad (MD5): {recon_hash}</em></p>
        
        <h3>2. Auditoría del Sistema (Vía PowerShell)</h3>
        <h4>Procesos Top:</h4>
        <ul>
            {''.join([f"<li>{p['Name']} (PID: {p['Id']})</li>" for p in audit_data.get('Procesos', [])])}
        </ul>
    </body>
    </html>
    """
    
    try:
        with open('../resultados/reporte_final.html', 'w') as f:
            f.write(html_content)
        logging.info("Reporte HTML generado exitosamente en resultados/reporte_final.html")
    except Exception as e:
        logging.error(f"Fallo al escribir el reporte HTML: {e}")

if __name__ == "__main__":
    generar_reporte_html()