$OutputFile = "..\resultados\audit_data.json"
$LogFile = "..\logs\sistema.log"

# Escribimos en el log usando ASCII para evitar broncas de formato
$Timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
"$Timestamp - INFO: Auditoria de sistema (PowerShell) ejecutada exitosamente" | Out-File -FilePath $LogFile -Append -Encoding ASCII

# Sacamos solo 10 procesos básicos, cero permisos de administrador
$Procesos = Get-Process | Select-Object Name, Id | Select-Object -First 10
$Data = @{ Procesos = $Procesos }

# Exportamos el JSON forzando ASCII, así Python lo lee perfecto
$Data | ConvertTo-Json -Depth 3 | Out-File -FilePath $OutputFile -Encoding ASCII